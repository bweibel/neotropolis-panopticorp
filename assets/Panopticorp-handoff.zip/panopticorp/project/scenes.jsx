// scenes.jsx — Panopticorp boot-up / logo reveal composition.
// 13s timeline, 1920×1080. Tightened pacing, long hold at the end.

const W = 1920, H = 1080;
const CX = W / 2, CY = H / 2;

// Catchphrase options (picked by tweak). One at a time — never stack them.
const CATCHPHRASES = {
  penetrative: {
    big: <>PERVASIVE. PERSISTENT. <span style={{ color: 'var(--amber)' }}>PENETRATIVE.</span></>,
    sub: 'IF IT HAPPENS · WE KNOW',
  },
  range: {
    big: <>EVERYONE IS <span style={{ color: 'var(--amber)' }}>WITHIN&nbsp;RANGE</span></>,
    sub: 'PANOPTICORP · SECTOR 7',
  },
  knowing: {
    big: <>IF IT HAPPENS · <span style={{ color: 'var(--amber)' }}>WE KNOW.</span></>,
    sub: 'GLOBAL AWARENESS · DELIVERED',
  },
  delivered: {
    big: <>GLOBAL AWARENESS. <span style={{ color: 'var(--amber)' }}>DELIVERED.</span></>,
    sub: 'IRIS-7 · PANOPTICORP ®',
  },
};

// ── Scene 1 — Cold boot (tighter) ─────────────────────────────────────────
function S1_ColdBoot() {
  const { localTime } = useSprite();
  let flicker = 0;
  if (localTime < 0.12) flicker = 1;
  else if (localTime < 0.22) flicker = 0;
  else if (localTime < 0.28) flicker = 0.6;

  const lineSweep = animate({ from: -20, to: H + 20, start: 0, end: 1.0, ease: Easing.easeInOutCubic })(localTime);

  return (
    <>
      <div style={{ position: 'absolute', inset: 0, background: P.cream, opacity: flicker }} />
      <div style={{
        position: 'absolute', left: 0, right: 0,
        top: lineSweep, height: 3,
        background: P.cream,
        boxShadow: `0 0 36px ${P.cream}, 0 0 6px ${P.cream}`,
        opacity: localTime > 0.25 ? 0.85 : 0,
      }} />
      {localTime > 0.4 && (
        <div style={{
          position: 'absolute', left: 0, right: 0, top: CY - 40,
          textAlign: 'center',
          fontFamily: FONT_MONO,
          fontSize: 56,
          fontWeight: 700,
          color: P.amber,
          letterSpacing: '0.35em',
          opacity: Math.sin(localTime * 10) > 0 ? 1 : 0.25,
          textTransform: 'uppercase',
        }}>
          ·· ACQUIRING SUBJECT ··
        </div>
      )}
    </>
  );
}

// ── Scene 2 — Diagnostics (tighter) ───────────────────────────────────────
function S2_Diagnostics() {
  const { localTime } = useSprite();
  const gridSize = 120;
  const cols = Math.ceil(W / gridSize);
  const rows = Math.ceil(H / gridSize);
  const gridProgress = clamp(localTime / 0.5, 0, 1);

  return (
    <>
      <svg width={W} height={H} style={{ position: 'absolute', inset: 0, opacity: 0.22 }}>
        {Array.from({ length: cols + 1 }).map((_, i) => {
          const x = i * gridSize;
          const t = clamp((gridProgress * 1.2 - i / cols), 0, 1);
          return <line key={`v${i}`} x1={x} y1={0} x2={x} y2={H * t} stroke={P.cream} strokeWidth="1" />;
        })}
        {Array.from({ length: rows + 1 }).map((_, i) => {
          const y = i * gridSize;
          const t = clamp((gridProgress * 1.2 - i / rows), 0, 1);
          return <line key={`h${i}`} x1={0} y1={y} x2={W * t} y2={y} stroke={P.cream} strokeWidth="1" />;
        })}
      </svg>

      <svg width={420} height={420} style={{
        position: 'absolute', left: CX - 210, top: CY - 210,
        opacity: clamp((localTime - 0.15) / 0.3, 0, 1),
      }}>
        <circle cx="210" cy="210" r="180" fill="none" stroke={P.amber} strokeWidth="2" strokeDasharray="6 10" />
        <circle cx="210" cy="210" r="100" fill="none" stroke={P.cream} strokeWidth="2" />
        <line x1="210" y1="0" x2="210" y2="420" stroke={P.cream} strokeWidth="1.5" opacity="0.5" />
        <line x1="0" y1="210" x2="420" y2="210" stroke={P.cream} strokeWidth="1.5" opacity="0.5" />
        <text x="398" y="206" fontFamily={FONT_MONO} fontSize="22" fontWeight="700" fill={P.amber} letterSpacing="1" textAnchor="end">X: 0960</text>
        <text x="218" y="28" fontFamily={FONT_MONO} fontSize="22" fontWeight="700" fill={P.amber} letterSpacing="1">Y: 0540</text>
      </svg>

      <div style={{ position: 'absolute', left: 80, top: 120, fontSize: 34, lineHeight: 1.5 }}>
        <Sprite start={0.05} end={1.8}>
          <TerminalLine text="PANOPTICORP / IRIS-7 / FW 0x3A.41.92" x={0} y={0} size={32} charTime={0.012} />
        </Sprite>
        <Sprite start={0.28} end={1.8}>
          <TerminalLine text="CIVIC CERTAINTY ENGINE :: INIT" x={0} y={54} size={32} charTime={0.012} />
        </Sprite>
        <Sprite start={0.55} end={1.8}>
          <TerminalLine text="PROBABILITY MODEL ..... OK" x={0} y={108} size={32} charTime={0.01} prefixColor={P.green} />
        </Sprite>
        <Sprite start={0.72} end={1.8}>
          <TerminalLine text="NEURAL MESH ........... OK" x={0} y={162} size={32} charTime={0.01} prefixColor={P.green} />
        </Sprite>
        <Sprite start={0.88} end={1.8}>
          <TerminalLine text="APERTURE .............. STANDBY" x={0} y={216} size={32} charTime={0.01} prefixColor={P.amber} />
        </Sprite>
      </div>

      <div style={{
        position: 'absolute', right: 80, bottom: 110,
        opacity: clamp((localTime - 0.5) / 0.2, 0, 1),
      }}>
        <Barcode x={0} y={0} seed={7419} width={420} height={88} color={P.cream} />
      </div>

      <div style={{
        position: 'absolute', left: 80, bottom: 120,
        display: 'flex', gap: 6, alignItems: 'flex-end',
        opacity: clamp((localTime - 0.4) / 0.2, 0, 1),
      }}>
        {[...Array(16)].map((_, i) => {
          const fill = clamp((localTime - 0.4) * 14 - i * 0.4, 0, 1);
          return <div key={i} style={{
            width: 14, height: 18 + i * 4,
            background: fill > 0.5 ? P.amber : 'rgba(236,230,218,0.15)',
          }} />;
        })}
        <div style={{
          marginLeft: 20, fontFamily: FONT_MONO, fontSize: 26, fontWeight: 700,
          color: P.creamDim, letterSpacing: '0.14em', textTransform: 'uppercase',
        }}>GAIN 14.2dB</div>
      </div>
    </>
  );
}

// ── Scene 3 — Iris draw-in (tighter, no competing catchphrase) ────────────
function S3_IrisDraw() {
  const { localTime } = useSprite();
  const drawProgress = clamp(localTime / 1.1, 0, 1);
  const eyeOpen = clamp((localTime - 1.1) / 0.5, 0, 1);
  const scalePulse = localTime > 1.6 ? 1 + Math.sin((localTime - 1.6) * 6) * 0.008 : 1;
  const glitch = (localTime > 1.35 && localTime < 1.5) ? 0.6 : 0;

  return (
    <div style={{
      position: 'absolute', inset: 0,
      transform: `scale(${scalePulse})`,
      transformOrigin: 'center',
    }}>
      <Glitch intensity={glitch} rgbShift={14}>
        <Iris
          cx={CX} cy={CY - 40}
          size={960}
          drawProgress={drawProgress}
          eyeOpen={eyeOpen}
          pupilX={0}
          glow={0.18 + Math.sin(localTime * 2) * 0.05}
          color={P.cream}
        />
      </Glitch>
    </div>
  );
}

// ── Scene 4 — Tracking (tighter, no HUD catchphrase clutter) ──────────────
function S4_Tracking() {
  const { localTime } = useSprite();

  const pupilX = interpolate(
    [0, 0.4, 0.9, 1.3, 1.6],
    [0, -0.85, 0.85, -0.3, 0],
    Easing.easeInOutCubic
  )(localTime);

  const glitch = (localTime > 1.45 && localTime < 1.6) ? 1 : 0;

  return (
    <>
      <Glitch intensity={glitch} rgbShift={24}>
        <Iris
          cx={CX} cy={CY - 40}
          size={960}
          drawProgress={1}
          eyeOpen={1}
          pupilX={pupilX}
          glow={0.22}
          color={P.cream}
        />
      </Glitch>

      <svg width={180} height={180} style={{
        position: 'absolute',
        left: CX - 90 + pupilX * 280,
        top: CY - 130,
        opacity: 0.75,
      }}>
        <path d="M 10 10 L 10 40 M 10 10 L 40 10" stroke={P.amber} strokeWidth="3" fill="none" />
        <path d="M 170 10 L 170 40 M 170 10 L 140 10" stroke={P.amber} strokeWidth="3" fill="none" />
        <path d="M 10 170 L 10 140 M 10 170 L 40 170" stroke={P.amber} strokeWidth="3" fill="none" />
        <path d="M 170 170 L 170 140 M 170 170 L 140 170" stroke={P.amber} strokeWidth="3" fill="none" />
      </svg>

      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 180,
        display: 'flex', justifyContent: 'center', gap: 48,
        fontFamily: FONT_MONO, fontSize: 30, fontWeight: 700,
        color: P.cream, letterSpacing: '0.14em', textTransform: 'uppercase',
      }}>
        <div><span style={{ color: P.amber }}>▸</span> ACQUISITION</div>
        <div><span style={{ color: P.amber }}>▸</span> TRACKING</div>
        <div><span style={{ color: P.green }}>▸</span> NOMINAL</div>
        <div style={{ color: P.amber }}>REC •</div>
      </div>
    </>
  );
}

// ── Scene 5 — Wordmark lockup + single catchphrase + LONG HOLD ────────────
function S5_Lockup({ catchphrase = 'penetrative' }) {
  const { localTime } = useSprite();
  const phrase = CATCHPHRASES[catchphrase] || CATCHPHRASES.penetrative;

  // Iris moves up + scales down to make room
  const riseT = clamp(localTime / 0.5, 0, 1);
  const irisScale = 1 - riseT * 0.35;
  const irisY = -riseT * 220;

  // Wordmark wipe-reveal (shortened so we spend more time on hold)
  const revealT = clamp((localTime - 0.35) / 0.9, 0, 1);
  const wmWidth = 1680;
  const wmRevealW = wmWidth * revealT;

  // Catchphrase fades in after wordmark settles
  const bigT = clamp((localTime - 1.35) / 0.45, 0, 1);
  const subT = clamp((localTime - 1.7) / 0.4, 0, 1);

  // Subtle breathing bloom during hold
  const holdGlow = Math.max(0, Math.sin((localTime - 1.5) * 1.3) * 0.25);

  return (
    <>
      {/* Iris */}
      <div style={{
        position: 'absolute', inset: 0,
        transform: `translateY(${irisY}px) scale(${irisScale})`,
        transformOrigin: 'center',
      }}>
        <Iris
          cx={CX} cy={CY - 40}
          size={960}
          drawProgress={1}
          eyeOpen={1}
          pupilX={Math.sin(localTime * 1.6) * 0.08}
          glow={0.28 + holdGlow * 0.4}
          color={P.cream}
        />
      </div>

      {/* Wordmark — centered below, wipe-revealed */}
      <div style={{
        position: 'absolute',
        left: CX - wmWidth / 2,
        top: CY + 300,
        width: wmWidth,
        height: wmWidth * (71.813324 / 1021.4173),
        opacity: revealT > 0 ? 1 : 0,
        overflow: 'hidden',
      }}>
        <div style={{ width: wmRevealW, height: '100%', overflow: 'hidden' }}>
          <WordmarkSVG width={wmWidth} glow={0.4 + holdGlow} />
        </div>
      </div>

      {/* Rule */}
      <div style={{
        position: 'absolute',
        left: CX, top: CY + 440,
        width: bigT * 1100,
        height: 3,
        background: P.amber,
        transform: 'translateX(-50%)',
      }} />

      {/* BIG catchphrase (one, never many) */}
      <div style={{
        position: 'absolute',
        left: 0, right: 0, top: CY + 472,
        textAlign: 'center',
        fontFamily: FONT_HEADING,
        fontSize: 88,
        fontWeight: 900,
        color: P.cream,
        letterSpacing: '0.18em',
        textTransform: 'uppercase',
        whiteSpace: 'nowrap',
        opacity: bigT,
        transform: `translateY(${(1 - bigT) * 20}px)`,
        textShadow: `0 0 ${18 + holdGlow * 48}px ${P.amber}`,
        // Map the var(--amber) used inside CATCHPHRASES
        ['--amber']: P.amber,
      }}>
        {phrase.big}
      </div>

      {/* Small sub-line */}
      <div style={{
        position: 'absolute',
        left: 0, right: 0, top: CY + 600,
        textAlign: 'center',
        fontFamily: FONT_MONO,
        fontSize: 28,
        fontWeight: 700,
        color: P.creamDim,
        letterSpacing: '0.45em',
        textTransform: 'uppercase',
        whiteSpace: 'nowrap',
        opacity: subT,
      }}>
        {phrase.sub}
      </div>
    </>
  );
}

// ── Scene 6 — Sign-off (tight collapse) ───────────────────────────────────
function S6_SignOff({ catchphrase = 'penetrative' }) {
  const { localTime } = useSprite();
  const phrase = CATCHPHRASES[catchphrase] || CATCHPHRASES.penetrative;
  const collapse = animate({ from: 1, to: 0.002, start: 0.25, end: 0.75, ease: Easing.easeInCubic })(localTime);
  const lineFade = animate({ from: 1, to: 0, start: 0.7, end: 1.0, ease: Easing.easeOutCubic })(localTime);

  return (
    <>
      <div style={{
        position: 'absolute', inset: 0,
        transform: `scaleY(${collapse})`,
        transformOrigin: 'center',
      }}>
        <Iris cx={CX} cy={CY - 260} size={960 * 0.65}
          drawProgress={1} eyeOpen={1} pupilX={0} glow={0.28} color={P.cream} />
        <div style={{ position: 'absolute', left: CX - 840, top: CY + 80, width: 1680 }}>
          <WordmarkSVG width={1680} glow={0.4} />
        </div>
        <div style={{ position: 'absolute', left: CX - 550, top: CY + 220, width: 1100, height: 3, background: P.amber }} />
        <div style={{
          position: 'absolute', left: 0, right: 0, top: CY + 252,
          textAlign: 'center',
          fontFamily: FONT_HEADING, fontSize: 88, fontWeight: 900, color: P.cream,
          letterSpacing: '0.18em', textTransform: 'uppercase', whiteSpace: 'nowrap',
          textShadow: `0 0 18px ${P.amber}`,
          ['--amber']: P.amber,
        }}>
          {phrase.big}
        </div>
      </div>

      <div style={{
        position: 'absolute', left: 0, right: 0,
        top: CY, height: 3,
        background: P.cream,
        opacity: lineFade,
        boxShadow: `0 0 36px ${P.cream}`,
      }} />
    </>
  );
}

// ── Persistent chrome ─────────────────────────────────────────────────────
function Chrome() {
  const t = useTime();
  return (
    <>
      <RegMarks inset={50} size={40} showLabels={false} />
      <div style={{
        position: 'absolute', left: 110, top: 62,
        fontFamily: FONT_MONO, fontSize: 22, fontWeight: 700,
        color: P.creamDim, letterSpacing: '0.16em', textTransform: 'uppercase',
      }}>
        REC · 04/22/26 · 02:17:{String(Math.floor((t * 14) % 60)).padStart(2, '0')}
      </div>
      <div style={{
        position: 'absolute', right: 110, top: 62,
        fontFamily: FONT_MONO, fontSize: 22, fontWeight: 700,
        color: P.amber, letterSpacing: '0.16em', textTransform: 'uppercase',
        display: 'flex', gap: 18, alignItems: 'center',
      }}>
        <span style={{
          display: 'inline-block', width: 14, height: 14,
          background: P.amber, borderRadius: '50%',
          opacity: Math.sin(t * 4) > 0 ? 1 : 0.2,
        }} />
        LIVE · SECTOR 7
      </div>
      <div style={{
        position: 'absolute', left: 110, bottom: 58,
        fontFamily: FONT_MONO, fontSize: 22, fontWeight: 700,
        color: P.creamDim, letterSpacing: '0.16em', textTransform: 'uppercase',
      }}>
        IRIS-7 · NODE 004
      </div>
      <div style={{
        position: 'absolute', right: 110, bottom: 58,
        fontFamily: FONT_MONO, fontSize: 22, fontWeight: 700,
        color: P.creamDim, letterSpacing: '0.16em', textTransform: 'uppercase',
      }}>
        CH 04/07
      </div>
    </>
  );
}

// ── Master composition ────────────────────────────────────────────────────
// Tightened timeline, LONG hold on S5:
//   S1 cold boot      0.00 → 1.10  (1.10s)  tighter
//   S2 diagnostics    1.10 → 2.80  (1.70s)  tighter
//   S3 iris draw      2.80 → 4.70  (1.90s)  tighter, no sub-catchphrase
//   S4 tracking       4.70 → 6.40  (1.70s)  tighter
//   S5 lockup + hold  6.40 → 12.20 (5.80s)  reveal ~1.8s + ~4s HOLD on catchphrase
//   S6 sign-off       12.20 → 13.00 (0.80s)
// Total: 13s (down from 16s), with the catchphrase + lockup on screen for ~4s
function BootUp({ tweaks }) {
  const t = useTime();
  React.useEffect(() => {
    const el = document.getElementById('video-root');
    if (el) el.setAttribute('data-screen-label', `t=${t.toFixed(1)}s`);
  }, [Math.floor(t)]);

  const showChrome = tweaks.showChrome !== false;
  const showScanlines = tweaks.scanlines !== false;
  const showGrain = tweaks.grain !== false;
  const scanlineIntensity = tweaks.scanlineIntensity ?? 0.9;
  const catchphrase = tweaks.catchphrase || 'penetrative';

  return (
    <div id="video-root" style={{ position: 'absolute', inset: 0, background: P.black }}>
      <Sprite start={0} end={1.1}><S1_ColdBoot /></Sprite>
      <Sprite start={1.1} end={2.8}><S2_Diagnostics /></Sprite>
      <Sprite start={2.8} end={4.7}><S3_IrisDraw /></Sprite>
      <Sprite start={4.7} end={6.4}><S4_Tracking /></Sprite>
      <Sprite start={6.4} end={12.2}><S5_Lockup catchphrase={catchphrase} /></Sprite>
      <Sprite start={12.2} end={13.0}><S6_SignOff catchphrase={catchphrase} /></Sprite>

      {showChrome && (
        <Sprite start={1.0} end={12.2}>
          <Chrome />
        </Sprite>
      )}

      {showScanlines && <CRTOverlay intensity={scanlineIntensity} />}
      {showGrain && <NoiseGrain intensity={0.12} />}
    </div>
  );
}

Object.assign(window, {
  S1_ColdBoot, S2_Diagnostics, S3_IrisDraw, S4_Tracking,
  S5_Lockup, S6_SignOff, Chrome, BootUp, WordmarkSVG,
  CATCHPHRASES,
});

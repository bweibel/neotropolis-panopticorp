// iris.jsx — The Panopticorp iris (eye) logo. Designed to match the attached mock.
// The "shell" is a rounded cream oval with a horizontal black slit; the pupil is a cream dot.
// All geometry is driven by props so it can be animated.

function Iris({
  cx = 500, cy = 500,
  size = 640,           // overall width
  eyeOpen = 1,          // 0 = closed line, 1 = fully open
  pupilX = 0,           // -1..1 : pupil horizontal offset within slit
  pupilScale = 1,       // pupil radius scale
  color = P.cream,
  drawProgress = 1,     // 0..1 : stroke-draw reveal
  glow = 0,             // 0..1 : phosphor bloom
  eyeShape = 'wide',    // 'wide' | 'round' | 'squint'
}) {
  // Outer "lens" oval -- roughly 1.36:1 aspect ratio (wide)
  const aspects = {
    wide:   { rx: 0.50, ry: 0.38 },
    round:  { rx: 0.46, ry: 0.42 },
    squint: { rx: 0.50, ry: 0.30 },
  };
  const { rx: rxR, ry: ryR } = aspects[eyeShape] || aspects.wide;
  const shellRX = size * rxR;
  const shellRY = size * ryR * (0.9 + 0.1 * eyeOpen);

  // Slit (inner black almond)
  const slitRX = shellRX * 0.70;
  const slitRY = shellRY * 0.22 * Math.max(0.02, eyeOpen);

  // Pupil
  const pupilR = slitRY * 0.85 * pupilScale;
  const pupilOffset = (slitRX - pupilR * 1.6) * pupilX;

  // Shell perimeter for stroke-draw
  const shellPerim = Math.PI * (3 * (shellRX + shellRY) - Math.sqrt((3 * shellRX + shellRY) * (shellRX + 3 * shellRY)));
  const dashOffset = shellPerim * (1 - drawProgress);

  return (
    <svg
      width={size * 1.1} height={size * 1.1}
      viewBox={`${cx - size * 0.55} ${cy - size * 0.55} ${size * 1.1} ${size * 1.1}`}
      style={{
        position: 'absolute',
        left: cx - size * 0.55,
        top: cy - size * 0.55,
        filter: glow > 0 ? `drop-shadow(0 0 ${16 * glow}px ${color}) drop-shadow(0 0 ${40 * glow}px ${color})` : 'none',
      }}
      shapeRendering="crispEdges"
    >
      {/* Outer shell — stroked then filled */}
      <ellipse
        cx={cx} cy={cy}
        rx={shellRX} ry={shellRY}
        fill={drawProgress >= 0.98 ? color : 'none'}
        stroke={color}
        strokeWidth={6}
        strokeDasharray={shellPerim}
        strokeDashoffset={dashOffset}
      />
      {/* Slit (black almond) — fade in as shell completes */}
      {drawProgress > 0.55 && (
        <ellipse
          cx={cx} cy={cy}
          rx={slitRX}
          ry={slitRY}
          fill={P.black}
          opacity={clamp((drawProgress - 0.55) / 0.3, 0, 1)}
        />
      )}
      {/* Pupil */}
      {drawProgress > 0.85 && eyeOpen > 0.2 && (
        <circle
          cx={cx + pupilOffset} cy={cy}
          r={pupilR}
          fill={color}
          opacity={clamp((drawProgress - 0.85) / 0.15, 0, 1)}
        />
      )}
    </svg>
  );
}

// Eye that "tracks" — pupil follows a target offset, small saccades
function TrackingIris(props) {
  const t = useTime();
  // Soft saccade pattern
  const pupilX = Math.sin(t * 0.7) * 0.6 + Math.sin(t * 2.3) * 0.15;
  const blink = (Math.sin(t * 0.55) > 0.97) ? 0.1 : 1;
  return <Iris {...props} pupilX={pupilX} eyeOpen={blink} />;
}

Object.assign(window, { Iris, TrackingIris });

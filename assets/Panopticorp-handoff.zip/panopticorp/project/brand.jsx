// brand.jsx — Panopticorp brand tokens + reusable chrome elements.
// Cream on black, amber terminal accents. Bitmap display + clean mono.

const P = {
  cream: '#ECE6DA',
  creamDim: '#A9A396',
  creamGhost: 'rgba(236,230,218,0.35)',
  black: '#140E00',           // brand base
  blackInk: '#0a0700',
  amber: '#EA691C',           // brand primary
  amberHot: '#FF8A3D',
  amberDim: 'rgba(234,105,28,0.55)',
  amberDark: '#502310',       // brand primary-dark
  contrast: '#3A947D',        // brand contrast (teal)
  red: '#C54A3A',
  green: '#3A947D',           // use the brand teal in place of phosphor
};

// Fonts: Ethnocentric (display/headings), Orbitron (body), VT323 (bitmap tickers), Space Mono (terminal)
const FONT_HEADING = "'Ethnocentric', 'Orbitron', 'Arial Black', sans-serif";
const FONT_BODY = "'Orbitron', 'Eurostile', sans-serif";
const FONT_DISPLAY = "'VT323', 'Courier New', monospace";
const FONT_MONO = "'Space Mono', 'JetBrains Mono', ui-monospace, monospace";

// ── CRT / scanline overlay ─────────────────────────────────────────────────
function CRTOverlay({ intensity = 1, vignette = true }) {
  const t = useTime();
  // Scanline jitter — very subtle
  const jitter = Math.sin(t * 3.7) * 0.6;
  return (
    <div style={{
      position: 'absolute', inset: 0,
      pointerEvents: 'none',
      zIndex: 90,
    }}>
      {/* Horizontal scanlines */}
      <div style={{
        position: 'absolute', inset: 0,
        background: `repeating-linear-gradient(
          to bottom,
          rgba(0,0,0,0) 0px,
          rgba(0,0,0,0) 2px,
          rgba(0,0,0,${0.32 * intensity}) 3px,
          rgba(0,0,0,0) 4px
        )`,
        mixBlendMode: 'multiply',
        transform: `translateY(${jitter}px)`,
      }} />
      {/* Slow rolling scan bar */}
      <div style={{
        position: 'absolute',
        left: 0, right: 0,
        top: `${((t * 8) % 120) - 10}%`,
        height: '18%',
        background: 'linear-gradient(to bottom, rgba(236,230,218,0) 0%, rgba(236,230,218,0.04) 50%, rgba(236,230,218,0) 100%)',
        mixBlendMode: 'screen',
        pointerEvents: 'none',
      }} />
      {/* RGB subpixel mask */}
      <div style={{
        position: 'absolute', inset: 0,
        background: `repeating-linear-gradient(
          to right,
          rgba(255,120,60,${0.06 * intensity}) 0px,
          rgba(120,255,120,${0.03 * intensity}) 1px,
          rgba(120,180,255,${0.06 * intensity}) 2px,
          rgba(0,0,0,0) 3px
        )`,
        mixBlendMode: 'screen',
      }} />
      {vignette && (
        <div style={{
          position: 'absolute', inset: 0,
          background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 45%, rgba(0,0,0,0.55) 100%)',
          pointerEvents: 'none',
        }} />
      )}
    </div>
  );
}

// ── Noise / grain layer ────────────────────────────────────────────────────
function NoiseGrain({ intensity = 0.08 }) {
  const t = useTime();
  // Animate via shifted background position each render
  const shift = Math.floor(t * 37) * 13;
  return (
    <div style={{
      position: 'absolute', inset: 0,
      zIndex: 85,
      pointerEvents: 'none',
      opacity: intensity,
      backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='1.2' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0.93  0 0 0 0 0.9  0 0 0 0 0.85  0 0 0 1 0'/></filter><rect width='100%25' height='100%25' filter='url(%23n)'/></svg>")`,
      backgroundSize: '200px 200px',
      backgroundPosition: `${shift % 200}px ${(shift * 7) % 200}px`,
      mixBlendMode: 'screen',
    }} />
  );
}

// ── Corner registration marks ──────────────────────────────────────────────
function RegMarks({ color = P.cream, inset = 40, size = 28, showLabels = true }) {
  const mark = (x, y, rot) => (
    <svg width={size} height={size} viewBox="0 0 28 28"
      style={{ position: 'absolute', [x]: inset, [y]: inset, transform: `rotate(${rot}deg)` }}>
      <circle cx="14" cy="14" r="6" fill="none" stroke={color} strokeWidth="1" />
      <line x1="14" y1="0" x2="14" y2="9" stroke={color} strokeWidth="1" />
      <line x1="14" y1="19" x2="14" y2="28" stroke={color} strokeWidth="1" />
      <line x1="0" y1="14" x2="9" y2="14" stroke={color} strokeWidth="1" />
      <line x1="19" y1="14" x2="28" y2="14" stroke={color} strokeWidth="1" />
    </svg>
  );
  return (
    <>
      {mark('left', 'top', 0)}
      {mark('right', 'top', 90)}
      {mark('right', 'bottom', 180)}
      {mark('left', 'bottom', 270)}
      {showLabels && (
        <>
          <CornerLabel x="left" y="top" inset={inset} size={size} offset={-8} text="◉ REC" />
          <CornerLabel x="right" y="top" inset={inset} size={size} offset={-8} text="SIGNAL ◉" align="right" />
          <CornerLabel x="left" y="bottom" inset={inset} size={size} offset={34} text="CH.01" />
          <CornerLabel x="right" y="bottom" inset={inset} size={size} offset={34} text="TRK 04/07" align="right" />
        </>
      )}
    </>
  );
}

function CornerLabel({ x, y, inset, size, offset, text, align = 'left' }) {
  const isRight = align === 'right';
  return (
    <div style={{
      position: 'absolute',
      [x]: inset + size + 10,
      [y]: y === 'top' ? inset + offset + 10 : inset + offset,
      ...(isRight ? {} : {}),
      fontFamily: FONT_MONO,
      fontSize: 13,
      letterSpacing: '0.08em',
      color: P.creamDim,
      textTransform: 'uppercase',
    }}>
      {text}
    </div>
  );
}

// ── Chrome strips ───────────────────────────────────────────────────────────
function TopStrip({ children }) {
  return (
    <div style={{
      position: 'absolute', top: 24, left: 120, right: 120,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontFamily: FONT_MONO, fontSize: 14, letterSpacing: '0.1em',
      color: P.creamDim, textTransform: 'uppercase',
      zIndex: 50,
    }}>
      {children}
    </div>
  );
}

function BottomStrip({ children }) {
  return (
    <div style={{
      position: 'absolute', bottom: 24, left: 120, right: 120,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      fontFamily: FONT_MONO, fontSize: 14, letterSpacing: '0.1em',
      color: P.creamDim, textTransform: 'uppercase',
      zIndex: 50,
    }}>
      {children}
    </div>
  );
}

// ── Terminal line — typewriter effect ──────────────────────────────────────
function TerminalLine({
  text,
  x, y,
  size = 22,
  color = P.cream,
  prefix = '>',
  prefixColor,
  charTime = 0.025,
  caret = true,
  font = FONT_MONO,
  letterSpacing = '0.05em',
}) {
  const { localTime } = useSprite();
  const charsShown = Math.min(text.length, Math.floor(localTime / charTime));
  const shown = text.slice(0, charsShown);
  const blink = Math.floor(localTime * 3) % 2 === 0;
  return (
    <div style={{
      position: 'absolute', left: x, top: y,
      fontFamily: font,
      fontSize: size,
      color,
      letterSpacing,
      whiteSpace: 'pre',
      textTransform: 'uppercase',
    }}>
      {prefix && (
        <span style={{ color: prefixColor || P.amber, marginRight: 12 }}>
          {prefix}
        </span>
      )}
      {shown}
      {caret && charsShown < text.length && <span style={{ opacity: blink ? 1 : 0 }}>_</span>}
    </div>
  );
}

// ── Barcode SVG ────────────────────────────────────────────────────────────
function Barcode({ x, y, seed = 42, width = 240, height = 54, color = P.cream }) {
  // Deterministic pseudo-random bars
  const bars = React.useMemo(() => {
    let s = seed;
    const rand = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
    const arr = [];
    let cursor = 0;
    while (cursor < width) {
      const w = 1 + Math.floor(rand() * 4);
      const filled = rand() > 0.35;
      if (filled) arr.push({ x: cursor, w });
      cursor += w + 1;
    }
    return arr;
  }, [seed, width]);
  return (
    <svg width={width} height={height} style={{ position: 'absolute', left: x, top: y }}>
      {bars.map((b, i) => <rect key={i} x={b.x} y={0} width={b.w} height={height - 16} fill={color} />)}
      <text x={0} y={height - 2} fontFamily={FONT_MONO} fontSize="11" fill={color} letterSpacing="2">
        {String(seed).padStart(4, '0')} · OCULAR · {Math.floor(seed * 7919) % 100000}
      </text>
    </svg>
  );
}

// ── Glitch wrapper — triggered by a 0..1 intensity ─────────────────────────
function Glitch({ intensity = 0, children, rgbShift = 8 }) {
  const t = useTime();
  if (intensity <= 0.001) return <>{children}</>;
  const tx = (Math.sin(t * 73) * 0.5 + Math.sin(t * 127) * 0.5) * rgbShift * intensity;
  const ty = Math.sin(t * 91) * rgbShift * 0.4 * intensity;
  const slice = Math.floor(t * 30) % 6 === 0 ? intensity : 0;
  return (
    <div style={{ position: 'relative' }}>
      <div style={{
        position: 'absolute', inset: 0,
        transform: `translate(${-tx}px, ${ty * 0.3}px)`,
        mixBlendMode: 'screen',
        filter: `drop-shadow(0 0 0 ${P.red})`,
        opacity: 0.6 * intensity,
      }}>{children}</div>
      <div style={{
        position: 'absolute', inset: 0,
        transform: `translate(${tx}px, ${-ty * 0.3}px)`,
        mixBlendMode: 'screen',
        opacity: 0.6 * intensity,
      }}>{children}</div>
      <div style={{
        transform: slice > 0.5 ? `translateX(${(Math.random() - 0.5) * 40 * intensity}px)` : 'none',
      }}>{children}</div>
    </div>
  );
}

Object.assign(window, {
  P, FONT_DISPLAY, FONT_MONO, FONT_HEADING, FONT_BODY,
  CRTOverlay, NoiseGrain, RegMarks, CornerLabel,
  TopStrip, BottomStrip, TerminalLine, Barcode, Glitch,
});
